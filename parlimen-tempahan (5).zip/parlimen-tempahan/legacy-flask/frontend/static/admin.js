(() => {
  const $ = (id) => document.getElementById(id);
  const LABEL = { pending: "Menunggu", confirmed: "Disahkan", cancelled: "Dibatalkan" };
  let token = "";

  const headers = () => ({ "X-Admin-Token": token, "Content-Type": "application/json" });

  function note(text, kind) {
    const m = $("msg");
    m.textContent = text;
    m.className = "msg " + kind;
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  async function load() {
    const status = $("statusFilter").value;
    const res = await fetch("/api/admin/bookings" + (status ? `?status=${status}` : ""), { headers: headers() });
    if (res.status === 401) { note("Token tidak sah.", "error"); $("panel").classList.add("hidden"); return; }
    let rows = await res.json();
    const from = $("from").value, to = $("to").value, house = $("houseFilter").value;
    rows = rows.filter((r) => (!from || r.date >= from) && (!to || r.date <= to) && (!house || r.house === house));
    $("msg").className = "msg hidden";
    $("panel").classList.remove("hidden");
    $("rows").innerHTML = rows.map((r) => `
      <tr>
        <td>${esc(r.reference)}</td>
        <td>${esc(r.date)}<br><small>${esc(r.day)}</small></td>
        <td>${esc(r.slot)}</td>
        <td>${esc(r.house)}</td>
        <td>${esc(r.name)}<br><small>${esc(r.email)}<br>${esc(r.phone)}${r.organisation ? "<br>" + esc(r.organisation) : ""}</small></td>
        <td>${r.group_size}</td>
        <td><span class="badge ${r.status}">${LABEL[r.status]}</span></td>
        <td>
          ${r.status === "pending" ? `<button data-id="${r.id}" data-s="confirmed">Sahkan</button>` : ""}
          ${r.status !== "cancelled" ? `<button data-id="${r.id}" data-s="cancelled">Batal</button>` : ""}
        </td>
      </tr>`).join("") || `<tr><td colspan="8">Tiada tempahan.</td></tr>`;
  }

  $("rows").onclick = async (e) => {
    const b = e.target.closest("button[data-id]");
    if (!b) return;
    if (b.dataset.s === "cancelled" && !confirm("Batalkan tempahan ini?")) return;
    const res = await fetch(`/api/admin/bookings/${b.dataset.id}/status`, { method: "POST", headers: headers(), body: JSON.stringify({ status: b.dataset.s }) });
    if (!res.ok) { const d = await res.json(); note(d.error, "error"); return; }
    load();
  };

  $("loginBtn").onclick = () => { token = $("token").value; load(); };
  ["statusFilter", "from", "to", "houseFilter"].forEach((id) => ($(id).onchange = load));

  $("exportBtn").onclick = async () => {
    const q = new URLSearchParams();
    if ($("from").value) q.set("from", $("from").value);
    if ($("to").value) q.set("to", $("to").value);
    if ($("houseFilter").value) q.set("house", $("houseFilter").value);
    const res = await fetch("/api/admin/export.xlsx?" + q, { headers: { "X-Admin-Token": token } });
    if (!res.ok) { note("Eksport gagal.", "error"); return; }
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `tempahan-disahkan-${new Date().toISOString().slice(0, 10)}.xlsx`;
    a.click();
    URL.revokeObjectURL(a.href);
  };
})();
