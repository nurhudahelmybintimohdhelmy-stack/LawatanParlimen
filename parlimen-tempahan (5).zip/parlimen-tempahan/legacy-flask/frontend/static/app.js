(() => {
  const MONTHS = ["Januari","Februari","Mac","April","Mei","Jun","Julai","Ogos","September","Oktober","November","Disember"];
  const DOW = ["Isn","Sel","Rab","Kha","Jum","Sab","Ahd"];
  const $ = (id) => document.getElementById(id);

  const state = { house: document.querySelector("#houseTabs button").dataset.house,
                  year: new Date().getFullYear(), month: new Date().getMonth(),
                  date: null, slot: null };

  function show(el, on) { el.classList.toggle("hidden", !on); }

  function message(text, kind) {
    const r = $("result");
    r.textContent = text;
    r.className = "msg " + kind;
    r.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  async function loadConfig() {
    const cfg = await (await fetch("/api/config")).json();
    $("maxPerDay").textContent = cfg.max_visits_per_day;
    $("bookingForm").group_size.max = cfg.max_group_size;
  }

  async function loadCalendar() {
    $("monthLabel").textContent = `${MONTHS[state.month]} ${state.year}`;
    const m = `${state.year}-${String(state.month + 1).padStart(2, "0")}`;
    const res = await fetch(`/api/availability?month=${m}&house=${encodeURIComponent(state.house)}`);
    const data = await res.json();
    const grid = $("calendar");
    grid.innerHTML = "";
    DOW.forEach((d) => { const e = document.createElement("div"); e.className = "dow"; e.textContent = d; grid.appendChild(e); });
    const lead = data.days[0].weekday;
    for (let i = 0; i < lead; i++) { const e = document.createElement("div"); e.className = "day empty"; grid.appendChild(e); }
    data.days.forEach((d) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "day";
      const n = Number(d.date.slice(8));
      b.innerHTML = `${n}`;
      if (d.bookable && d.remaining > 0) {
        b.classList.add("open");
        b.innerHTML += `<small>${d.remaining} baki</small>`;
        b.onclick = () => pickDate(d.date, b);
      } else if (d.bookable) {
        b.classList.add("full");
        b.innerHTML += "<small>Penuh</small>";
        b.disabled = true;
      } else {
        b.disabled = true;
      }
      if (d.date === state.date) b.classList.add("selected");
      grid.appendChild(b);
    });
  }

  async function pickDate(date, btn) {
    state.date = date; state.slot = null;
    document.querySelectorAll(".day.selected").forEach((e) => e.classList.remove("selected"));
    btn.classList.add("selected");
    show($("formCard"), false);
    show($("result"), false);
    const res = await fetch(`/api/slots?date=${date}&house=${encodeURIComponent(state.house)}`);
    const data = await res.json();
    if (!res.ok) { message(data.error, "error"); return; }
    $("slotTitle").textContent = `${state.house}, ${date}`;
    $("slotHint").textContent = `Baki kuota lawatan hari ini: ${data.remaining}. Slot yang dikelabukan telah ditempah.`;
    const box = $("slots");
    box.innerHTML = "";
    data.slots.forEach((s) => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "slot"; b.textContent = s.label; b.disabled = !s.available;
      b.onclick = () => {
        state.slot = s.id;
        box.querySelectorAll(".slot").forEach((e) => e.classList.remove("selected"));
        b.classList.add("selected");
        show($("formCard"), true);
        $("formCard").scrollIntoView({ behavior: "smooth", block: "nearest" });
      };
      box.appendChild(b);
    });
    show($("slotCard"), true);
  }

  document.querySelectorAll("#houseTabs button").forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll("#houseTabs button").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      state.house = b.dataset.house; state.date = null; state.slot = null;
      show($("slotCard"), false); show($("formCard"), false); show($("result"), false);
      loadCalendar();
    };
  });
  $("prevMonth").onclick = () => { state.month--; if (state.month < 0) { state.month = 11; state.year--; } loadCalendar(); };
  $("nextMonth").onclick = () => { state.month++; if (state.month > 11) { state.month = 0; state.year++; } loadCalendar(); };

  $("bookingForm").onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    $("submitBtn").disabled = true;
    const body = { house: state.house, date: state.date, slot: state.slot,
                   name: f.name.value, organisation: f.organisation.value, email: f.email.value,
                   phone: f.phone.value, group_size: f.group_size.value };
    try {
      const res = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (res.ok) {
        message(`${data.message} No. rujukan: ${data.reference}. Simpan nombor ini.`, "ok");
        f.reset(); show($("formCard"), false); show($("slotCard"), false); state.date = null;
        loadCalendar();
      } else {
        message(data.error, "error");
        if (res.status === 409) { loadCalendar(); }
      }
    } catch (err) {
      message("Ralat rangkaian. Sila cuba lagi.", "error");
    } finally {
      $("submitBtn").disabled = false;
    }
  };

  loadConfig();
  loadCalendar();
})();
