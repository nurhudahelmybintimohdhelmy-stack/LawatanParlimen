import os
import sys
from datetime import date, timedelta
from io import BytesIO

import pytest
from openpyxl import load_workbook

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import app as appmod  # noqa: E402

TOKEN = {"X-Admin-Token": appmod.ADMIN_TOKEN}


@pytest.fixture()
def client(tmp_path):
    db = str(tmp_path / "test.db")
    appmod.app.config["DB_PATH"] = db
    appmod.init_db(db)
    appmod.app.config["TESTING"] = True
    with appmod.app.test_client() as c:
        yield c


def next_weekday(weekday, after_days=7):
    d = date.today() + timedelta(days=after_days)
    while d.weekday() != weekday:
        d += timedelta(days=1)
    return d


def payload(d, slot=0, house="Dewan Rakyat", **kw):
    base = dict(house=house, date=d.isoformat(), slot=slot, name="Ali", email="ali@example.com",
                phone="0123456789", organisation="SK Test", group_size=10)
    base.update(kw)
    return base


def test_book_monday_ok(client):
    r = client.post("/api/bookings", json=payload(next_weekday(0)))
    assert r.status_code == 201
    assert r.json["reference"].startswith("PLK-")


@pytest.mark.parametrize("weekday", [4, 5, 6])
def test_fri_sat_sun_rejected(client, weekday):
    r = client.post("/api/bookings", json=payload(next_weekday(weekday)))
    assert r.status_code == 400
    assert "Isnin hingga Khamis" in r.json["error"]


def test_past_date_rejected(client):
    d = date.today() - timedelta(days=1)
    while d.weekday() > 3:
        d -= timedelta(days=1)
    assert client.post("/api/bookings", json=payload(d)).status_code == 400


def test_slot_double_booking_blocked(client):
    d = next_weekday(1)
    assert client.post("/api/bookings", json=payload(d, slot=2)).status_code == 201
    r = client.post("/api/bookings", json=payload(d, slot=2, email="b@example.com"))
    assert r.status_code == 409


def test_same_slot_different_house_allowed(client):
    d = next_weekday(1)
    assert client.post("/api/bookings", json=payload(d, slot=2)).status_code == 201
    assert client.post("/api/bookings", json=payload(d, slot=2, house="Dewan Negara")).status_code == 201


def test_max_four_per_day_per_house(client):
    d = next_weekday(2)
    for s in range(4):
        assert client.post("/api/bookings", json=payload(d, slot=s)).status_code == 201
    r = client.post("/api/bookings", json=payload(d, slot=7))
    assert r.status_code == 409
    assert "penuh" in r.json["error"].lower()
    # Dewan lain masih ada kuota
    assert client.post("/api/bookings", json=payload(d, slot=7, house="Dewan Negara")).status_code == 201


def test_slots_endpoint_has_eight_slots(client):
    d = next_weekday(3)
    r = client.get(f"/api/slots?date={d}&house=Dewan Rakyat")
    assert r.status_code == 200
    assert len(r.json["slots"]) == 8
    assert r.json["slots"][0]["label"] == "09:00 - 10:00"
    assert r.json["slots"][-1]["label"] == "16:00 - 17:00"


def test_availability_marks_weekends_closed(client):
    r = client.get("/api/availability?month=2027-03&house=Dewan Rakyat")
    assert r.status_code == 200
    for day in r.json["days"]:
        if day["weekday"] >= 4:
            assert day["bookable"] is False


def test_cancel_frees_slot(client):
    d = next_weekday(0)
    bid = client.post("/api/bookings", json=payload(d, slot=1)).json["id"]
    assert client.post(f"/api/admin/bookings/{bid}/status", json={"status": "cancelled"}, headers=TOKEN).status_code == 200
    assert client.post("/api/bookings", json=payload(d, slot=1, email="c@example.com")).status_code == 201


def test_admin_requires_token(client):
    assert client.get("/api/admin/bookings").status_code == 401
    assert client.get("/api/admin/export.xlsx").status_code == 401


def test_export_only_confirmed(client):
    d = next_weekday(0)
    a = client.post("/api/bookings", json=payload(d, slot=0)).json["id"]
    client.post("/api/bookings", json=payload(d, slot=1, name="Pending Orang"))
    client.post(f"/api/admin/bookings/{a}/status", json={"status": "confirmed"}, headers=TOKEN)
    r = client.get("/api/admin/export.xlsx", headers=TOKEN)
    assert r.status_code == 200
    ws = load_workbook(BytesIO(r.data)).active
    assert ws.max_row == 2  # tajuk + 1 tempahan disahkan
    assert ws.cell(row=2, column=6).value == "Ali"


def test_validation(client):
    d = next_weekday(0)
    assert client.post("/api/bookings", json=payload(d, email="bukan-emel")).status_code == 400
    assert client.post("/api/bookings", json=payload(d, slot=8)).status_code == 400
    assert client.post("/api/bookings", json=payload(d, house="Dewan Lain")).status_code == 400
    assert client.post("/api/bookings", json=payload(d, group_size=0)).status_code == 400
