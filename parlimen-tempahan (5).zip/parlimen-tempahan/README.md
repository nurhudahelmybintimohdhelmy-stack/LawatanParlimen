# Sistem Tempahan Lawatan Parlimen

Sistem web untuk menempah lawatan ke Parlimen Malaysia. Laman (HTML + JavaScript) dihos di **GitHub Pages**, manakala data disimpan dalam **Google Sheet** melalui **Google Apps Script**. Tiada pelayan dan tiada kos.

## Peraturan tempahan

| Peraturan | Nilai |
|---|---|
| Hari dibuka | Isnin – Khamis (Jumaat, Sabtu & Ahad ditutup) |
| Slot sehari | 8 slot, 9:00 pagi – 5:00 petang (1 jam setiap slot) |
| Kuota lawatan | Maksimum 4 lawatan sehari bagi setiap dewan |
| Dewan | Dewan Rakyat dan Dewan Negara (kalendar berasingan) |
| Tarikh | Hanya tarikh akan datang |
| Status | menunggu → disahkan (atau dibatalkan, slot kosong semula) |
| Eksport Excel | Hanya tempahan **disahkan** |

## Struktur folder

```
├── docs/                 # Laman web (GitHub Pages)
│   ├── index.html        # Borang tempahan + kalendar
│   ├── admin.html        # Panel admin
│   ├── css/style.css
│   └── js/
│       ├── config.js     # <-- ISI URL Apps Script anda di sini
│       ├── api.js, utils.js, app.js, admin.js
├── apps-script/
│   ├── Code.gs           # Backend (tampal dalam Apps Script)
│   └── appsscript.json   # Manifest
├── tests/                # Ujian (node --test), termasuk ujian Code.gs
└── legacy-flask/         # Versi lama Flask + SQLite (rujukan sahaja)
```

## Persediaan (sekali sahaja, ~10 minit)

### 1. Sheet + backend
1. Buka [sheets.new](https://sheets.new) → namakan "Tempahan Lawatan Parlimen".
2. **Extensions → Apps Script**. Padam kod sedia ada, tampal seluruh isi `apps-script/Code.gs`.
3. **Project Settings (ikon gear)** → tanda **Show "appsscript.json" manifest file** → kembali ke Editor → buka `appsscript.json` → tampal isi `apps-script/appsscript.json`.
4. Pilih fungsi **`setup`** di bar atas → **Run** → benarkan kebenaran (jika ada amaran "Google hasn't verified this app": *Advanced → Go to ... (unsafe)*; ini skrip anda sendiri).
5. Buka **Execution log**: ia memaparkan **token admin** anda. Simpan token ini. (Boleh ditukar di *Project Settings → Script properties → `ADMIN_TOKEN`*.)

`setup()` menyediakan sheet **Tempahan** (semua tempahan, lajur Status ada dropdown) dan sheet **Disahkan** (senarai tempahan disahkan sahaja, automatik).

### 2. Terbitkan sebagai Web App
**Deploy → New deployment → Select type: Web app**
- Execute as: **Me**
- Who has access: **Anyone**

Tekan **Deploy**, salin **Web app URL** (berakhir dengan `/exec`).

### 3. Sambung laman
Tampal URL itu dalam `docs/js/config.js`:
```js
export const APPS_SCRIPT_URL = "https://script.google.com/macros/s/XXXX/exec";
```

### 4. GitHub Pages
Push ke repo, kemudian **Settings → Pages → Deploy from a branch → `main` / folder `/docs`**.
Laman: `https://<username>.github.io/<nama-repo>/`.

> Setiap kali anda ubah `Code.gs`, pergi **Deploy → Manage deployments → ✏️ Edit → Version: New version → Deploy**. URL kekal sama.

## Cara admin bekerja

Dua cara, pilih mana yang selesa:

- **Terus dalam Google Sheet**: buka sheet *Tempahan*, tukar lajur **Status** kepada `confirmed` atau `cancelled`. "Disahkan Pada" diisi automatik. Untuk Excel: buka sheet **Disahkan** → **File → Download → Microsoft Excel (.xlsx)**.
- **Panel admin** (`admin.html`): masukkan token admin, sahkan / batal tempahan, tapis ikut tarikh atau dewan, dan tekan **Eksport Excel** (tempahan disahkan sahaja).

Tempahan yang dibatalkan kekal dalam Sheet sebagai rekod, tetapi slotnya terus kosong semula.

## Uji di komputer sendiri

```bash
npm run serve     # http://localhost:8080  (atau: python3 -m http.server 8080 --directory docs)
npm test          # 28 ujian: logik tarikh/slot di pelayar + seluruh logik Code.gs (dengan mock Apps Script)
```

## Keselamatan & had

- **Data peribadi** (nama, emel, telefon) hanya ada dalam Sheet dan API admin. API awam (kalendar/slot) hanya memulangkan nombor slot dan bilangan, tiada data peribadi. **Jangan kongsi Sheet secara awam.**
- Token admin menentukan akses panel admin. Guna token yang panjang, jangan simpan dalam repo, dan tukar jika bocor.
- Peraturan Isnin–Khamis, kuota dan slot unik dikuatkuasakan **di pelayan** (`Code.gs`), bukan di pelayar sahaja, dengan kunci (`LockService`) untuk elak dua tempahan serentak.
- Nama/emel/organisasi yang bermula dengan `= + - @` dineutralkan supaya tidak jadi formula dalam Sheet atau Excel.
- Apps Script ada kuota harian akaun Google percuma (beribu permintaan sehari), memadai untuk sistem ini. Respons agak perlahan (1–2 saat) kerana ciri Apps Script.
- Hari cuti umum / hari bersidang belum disekat automatik; tambah dalam `dateError_()` (`Code.gs`) dan `isBookable()` (`docs/js/utils.js`) jika perlu.
- Tiada emel pengesahan automatik; admin menghubungi penempah melalui emel/telefon yang direkodkan.

## Lesen

MIT
