import { test } from "node:test";
import assert from "node:assert/strict";
import { SLOTS, MAX_PER_DAY, isBookable, parseDate, esc } from "../docs/js/utils.js";

// 21 Okt 2026 ialah hari Rabu
const NOW = new Date(2026, 9, 21, 10, 0);

test("8 slot, 09:00 hingga 17:00", () => {
  assert.equal(SLOTS.length, 8);
  assert.equal(SLOTS[0].label, "09:00 - 10:00");
  assert.equal(SLOTS[7].label, "16:00 - 17:00");
});

test("kuota 4 lawatan sehari", () => assert.equal(MAX_PER_DAY, 4));

test("Isnin - Khamis akan datang boleh ditempah", () => {
  assert.equal(isBookable("2026-10-22", NOW), true); // Khamis
  assert.equal(isBookable("2026-10-26", NOW), true); // Isnin
  assert.equal(isBookable("2026-10-27", NOW), true); // Selasa
  assert.equal(isBookable("2026-10-28", NOW), true); // Rabu
});

test("Jumaat, Sabtu, Ahad ditolak", () => {
  assert.equal(isBookable("2026-10-23", NOW), false);
  assert.equal(isBookable("2026-10-24", NOW), false);
  assert.equal(isBookable("2026-10-25", NOW), false);
});

test("hari ini dan tarikh lepas ditolak", () => {
  assert.equal(isBookable("2026-10-21", NOW), false);
  assert.equal(isBookable("2026-10-19", NOW), false);
});

test("tarikh tidak sah ditolak", () => {
  assert.equal(parseDate("2026-02-30"), null);
  assert.equal(isBookable("bukan-tarikh", NOW), false);
  assert.equal(isBookable("", NOW), false);
});

test("esc melarikan aksara HTML", () => {
  assert.equal(esc('<b onclick="x">&'), "&lt;b onclick=&quot;x&quot;&gt;&amp;");
});
