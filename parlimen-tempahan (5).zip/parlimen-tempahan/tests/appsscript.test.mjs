// Menguji apps-script/Code.gs dalam Node dengan tiruan (mock) API Apps Script.
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import path from "node:path";

const CODE = fs.readFileSync(
  path.join(path.dirname(fileURLToPath(import.meta.url)), "../apps-script/Code.gs"), "utf8");
const TZ = "Asia/Kuala_Lumpur";
const TOKEN = "token-ujian-123";

// ---- tiruan Sheet ----
class MockSheet {
  constructor(name) { this.name = name; this.data = []; }
  getName() { return this.name; }
  getLastRow() { return this.data.length; }
  getRange(r, c, nr = 1, nc = 1) {
    const s = this;
    return {
      getValues: () => Array.from({ length: nr }, (_, i) =>
        Array.from({ length: nc }, (_, j) => (s.data[r - 1 + i] || [])[c - 1 + j] ?? "")),
      getValue: () => (s.data[r - 1] || [])[c - 1] ?? "",
      setValues: (v) => v.forEach((row, i) => row.forEach((val, j) => { (s.data[r - 1 + i] ||= [])[c - 1 + j] = val; })),
      setValue: (v) => { (s.data[r - 1] ||= [])[c - 1] = v; },
    };
  }
}

function fmt(d, tz, f) {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(d).map((x) => [x.type, x.value]));
  const h = p.hour === "24" ? "00" : p.hour;
  return f.replace("yyyy", p.year).replace("MM", p.month).replace("dd", p.day)
    .replace("HH", h).replace("mm", p.minute).replace("ss", p.second);
}

function makeEnv({ token = TOKEN, withSheet = true } = {}) {
  const sheet = new MockSheet("Tempahan");
  sheet.data[0] = ["Rujukan"]; // baris tajuk
  const props = { ADMIN_TOKEN: token };
  const ss = { getSheetByName: (n) => (withSheet && n === "Tempahan" ? sheet : null) };
  const ctx = {
    console: { error() {}, log() {} },
    SpreadsheetApp: { getActiveSpreadsheet: () => ss, openById: () => ss },
    PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] ?? null, setProperty: (k, v) => { props[k] = v; } }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    ContentService: {
      MimeType: { JSON: "json" },
      createTextOutput: (s) => ({ s, setMimeType() { return this; }, getContent() { return this.s; } }),
    },
    Utilities: { formatDate: fmt },
  };
  vm.createContext(ctx);
  vm.runInContext(CODE, ctx);
  return { ctx, sheet, props };
}

// tarikh (hari ini di KL) + n hari, kemudian cari hari minggu yang dikehendaki (0=Ahad..6=Sabtu)
function nextWeekday(weekday, minDays = 7) {
  const kl = new Date(Date.now() + 8 * 3600e3);
  const d = new Date(Date.UTC(kl.getUTCFullYear(), kl.getUTCMonth(), kl.getUTCDate() + minDays));
  while (d.getUTCDay() !== weekday) d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

const book = (ctx, date, over = {}) => ctx.handlePost_({
  action: "book", house: "Dewan Rakyat", date, slot: 0, name: "Ali", email: "ali@example.com",
  phone: "0123456789", organisation: "SK Test", group_size: 10, ...over,
});

test("tempahan hari Isnin berjaya dan masuk dalam sheet", () => {
  const { ctx, sheet } = makeEnv();
  const date = nextWeekday(1);
  const r = book(ctx, date);
  assert.equal(r.ok, true);
  assert.match(r.reference, /^PLK-[A-Z2-9]{6}$/);
  assert.equal(sheet.getLastRow(), 2);
  const row = sheet.data[1];
  assert.equal(row[1], date);
  assert.equal(row[2], "Isnin");
  assert.equal(row[3], "09:00 - 10:00");
  assert.equal(row[10], "pending");
});

test("Jumaat, Sabtu, Ahad ditolak", () => {
  const { ctx } = makeEnv();
  for (const wd of [5, 6, 0]) {
    const r = book(ctx, nextWeekday(wd));
    assert.equal(r.ok, false);
    assert.match(r.error, /Isnin hingga Khamis/);
  }
});

test("Isnin hingga Khamis semua boleh", () => {
  const { ctx } = makeEnv();
  for (const wd of [1, 2, 3, 4]) assert.equal(book(ctx, nextWeekday(wd), { slot: wd }).ok, true);
});

test("tarikh lepas dan hari ini ditolak", () => {
  const { ctx } = makeEnv();
  assert.equal(book(ctx, "2020-01-06").ok, false); // Isnin lepas
  const today = fmt(new Date(), TZ, "yyyy-MM-dd");
  assert.equal(book(ctx, today).ok, false);
});

test("double-booking slot yang sama ditolak (TAKEN)", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(2);
  assert.equal(book(ctx, d, { slot: 2 }).ok, true);
  const r = book(ctx, d, { slot: 2, email: "b@example.com" });
  assert.equal(r.ok, false);
  assert.equal(r.code, "TAKEN");
});

test("slot sama di dewan lain dibenarkan", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(2);
  assert.equal(book(ctx, d, { slot: 2 }).ok, true);
  assert.equal(book(ctx, d, { slot: 2, house: "Dewan Negara" }).ok, true);
});

test("maksimum 4 lawatan sehari bagi setiap dewan (FULL)", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(3);
  for (let s = 0; s < 4; s++) assert.equal(book(ctx, d, { slot: s }).ok, true);
  const r = book(ctx, d, { slot: 7 });
  assert.equal(r.ok, false);
  assert.equal(r.code, "FULL");
  assert.equal(book(ctx, d, { slot: 7, house: "Dewan Negara" }).ok, true); // dewan lain masih ada kuota
});

test("endpoint slot: taken, baki dan day_full", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  book(ctx, d, { slot: 1 });
  book(ctx, d, { slot: 5 });
  let r = ctx.handleGet_({ action: "slots", house: "Dewan Rakyat", date: d });
  assert.deepEqual([...r.taken].sort(), [1, 5]);
  assert.equal(r.remaining, 2);
  assert.equal(r.day_full, false);
  book(ctx, d, { slot: 6 });
  book(ctx, d, { slot: 7 });
  r = ctx.handleGet_({ action: "slots", house: "Dewan Rakyat", date: d });
  assert.equal(r.day_full, true);
  assert.equal(ctx.handleGet_({ action: "slots", house: "Dewan Rakyat", date: nextWeekday(5) }).ok, false);
});

test("availability memulangkan kiraan ikut tarikh dan dewan", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  book(ctx, d, { slot: 0 });
  book(ctx, d, { slot: 1 });
  book(ctx, d, { slot: 0, house: "Dewan Negara" });
  const r = ctx.handleGet_({ action: "availability", house: "Dewan Rakyat", month: d.slice(0, 7) });
  assert.equal(r.ok, true);
  assert.equal(r.counts[d], 2);
  assert.equal(r.max_per_day, 4);
  assert.equal(ctx.handleGet_({ action: "availability", house: "Dewan Rakyat", month: "2026-13" }).ok, false);
});

test("API awam tidak mendedahkan data peribadi", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  book(ctx, d, { name: "Rahsia Orang" });
  const s = JSON.stringify([
    ctx.handleGet_({ action: "slots", house: "Dewan Rakyat", date: d }),
    ctx.handleGet_({ action: "availability", house: "Dewan Rakyat", month: d.slice(0, 7) }),
  ]);
  assert.ok(!s.includes("Rahsia"));
  assert.ok(!s.includes("example.com"));
});

test("pengesahan input", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  assert.equal(book(ctx, d, { email: "bukan-emel" }).ok, false);
  assert.equal(book(ctx, d, { phone: "abc" }).ok, false);
  assert.equal(book(ctx, d, { slot: 8 }).ok, false);
  assert.equal(book(ctx, d, { slot: -1 }).ok, false);
  assert.equal(book(ctx, d, { slot: 1.5 }).ok, false);
  assert.equal(book(ctx, d, { slot: "" }).ok, false);
  assert.equal(book(ctx, d, { house: "Dewan Lain" }).ok, false);
  assert.equal(book(ctx, d, { group_size: 0 }).ok, false);
  assert.equal(book(ctx, d, { group_size: 51 }).ok, false);
  assert.equal(book(ctx, d, { name: "   " }).ok, false);
  assert.equal(book(ctx, d, { name: "x".repeat(101) }).ok, false);
});

test("formula berbahaya dineutralkan", () => {
  const { ctx, sheet } = makeEnv();
  const d = nextWeekday(1);
  assert.equal(book(ctx, d, { name: "=HYPERLINK(\"http://x\")", organisation: "@SUM(1)", phone: "+60123456789" }).ok, true);
  const row = sheet.data[1];
  assert.ok(row[5].startsWith("'="));
  assert.ok(row[8].startsWith("'@"));
  assert.equal(row[7], "+60123456789"); // telefon sah dengan + dikekalkan
});

test("admin memerlukan token yang betul", () => {
  const { ctx } = makeEnv();
  assert.equal(ctx.handlePost_({ action: "admin_list" }).code, "UNAUTHORIZED");
  assert.equal(ctx.handlePost_({ action: "admin_list", token: "salah" }).code, "UNAUTHORIZED");
  assert.equal(ctx.handlePost_({ action: "admin_status", token: "salah", reference: "x", status: "confirmed" }).code, "UNAUTHORIZED");
  assert.equal(ctx.handlePost_({ action: "admin_list", token: TOKEN }).ok, true);
});

test("jika ADMIN_TOKEN belum ditetapkan, semua akses admin ditolak", () => {
  const { ctx } = makeEnv({ token: "" });
  assert.equal(ctx.handlePost_({ action: "admin_list", token: "" }).code, "UNAUTHORIZED");
  assert.equal(ctx.handlePost_({ action: "admin_list" }).code, "UNAUTHORIZED");
});

test("admin sahkan tempahan dan ia muncul dengan status confirmed", () => {
  const { ctx, sheet } = makeEnv();
  const d = nextWeekday(1);
  const ref = book(ctx, d).reference;
  const r = ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: ref, status: "confirmed" });
  assert.equal(r.ok, true);
  assert.equal(sheet.data[1][10], "confirmed");
  assert.match(sheet.data[1][12], /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
  const list = ctx.handlePost_({ action: "admin_list", token: TOKEN });
  assert.equal(list.bookings.length, 1);
  assert.equal(list.bookings[0].status, "confirmed");
  assert.equal(list.bookings[0].slot, "09:00 - 10:00");
  assert.equal(list.bookings[0].day, "Isnin");
});

test("batal membebaskan slot dan kuota", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  const ref = book(ctx, d, { slot: 1 }).reference;
  assert.equal(ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: ref, status: "cancelled" }).ok, true);
  assert.equal(book(ctx, d, { slot: 1, email: "c@example.com" }).ok, true);
  // tempahan dibatalkan tidak boleh diubah semula
  assert.equal(ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: ref, status: "confirmed" }).code, "CONFLICT");
});

test("batal tidak mengira terhadap kuota 4 sehari", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(2);
  const refs = [0, 1, 2, 3].map((s) => book(ctx, d, { slot: s }).reference);
  assert.equal(book(ctx, d, { slot: 4 }).code, "FULL");
  ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: refs[0], status: "cancelled" });
  assert.equal(book(ctx, d, { slot: 4 }).ok, true);
});

test("status tidak sah dan rujukan tidak wujud", () => {
  const { ctx } = makeEnv();
  assert.equal(ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: "PLK-AAAAAA", status: "confirmed" }).code, "NOT_FOUND");
  assert.equal(ctx.handlePost_({ action: "admin_status", token: TOKEN, reference: "x", status: "pending" }).code, "INVALID");
});

test("onEdit mengisi 'Disahkan Pada' apabila status ditukar dalam Sheet", () => {
  const { ctx, sheet } = makeEnv();
  const ref = book(ctx, nextWeekday(1)).reference;
  assert.ok(ref);
  sheet.data[1][10] = "confirmed"; // admin tukar dalam Sheet
  const range = { getSheet: () => sheet, getColumn: () => 11, getRow: () => 2, getNumRows: () => 1, getNumColumns: () => 1 };
  ctx.onEdit({ range });
  assert.match(sheet.data[1][12], /^\d{4}-\d{2}-\d{2} /);
  sheet.data[1][10] = "pending";
  ctx.onEdit({ range });
  assert.equal(sheet.data[1][12], "");
});

test("doGet / doPost memulangkan JSON dan menangani input rosak", () => {
  const { ctx } = makeEnv();
  const d = nextWeekday(1);
  const out = ctx.doPost({ postData: { contents: JSON.stringify({ action: "book", house: "Dewan Rakyat", date: d, slot: 0, name: "A", email: "a@b.co", phone: "0123456", group_size: 1 }) } });
  assert.equal(JSON.parse(out.getContent()).ok, true);
  assert.equal(JSON.parse(ctx.doPost({ postData: { contents: "{rosak" } }).getContent()).code, "INVALID");
  assert.equal(JSON.parse(ctx.doGet({ parameter: {} }).getContent()).ok, true);
  assert.equal(JSON.parse(ctx.doPost({ postData: { contents: '{"action":"x"}' } }).getContent()).ok, false);
});

test("jika setup() belum dijalankan, mesej jelas dipulangkan", () => {
  const { ctx } = makeEnv({ withSheet: false });
  const r = ctx.handleGet_({ action: "availability", house: "Dewan Rakyat", month: "2030-01" });
  assert.equal(r.ok, false);
  assert.match(r.error, /setup/);
});
