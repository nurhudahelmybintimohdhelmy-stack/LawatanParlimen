# Sistem Tempahan Lawatan Parlimen

Sistem web untuk menempah lawatan ke Parlimen Malaysia, dengan kalendar berasingan untuk **Dewan Rakyat** dan **Dewan Negara**.

## Peraturan tempahan

| Peraturan | Nilai |
|---|---|
| Hari dibuka | Isnin – Khamis (Jumaat, Sabtu & Ahad ditutup) |
| Slot sehari | 8 slot, 9:00 pagi – 5:00 petang (1 jam setiap slot) |
| Kuota lawatan | Maksimum 4 lawatan sehari bagi setiap dewan |
| Tarikh | Hanya tarikh akan datang |
| Status | `pending` → `confirmed` (atau `cancelled`) |
| Eksport Excel | Hanya tempahan berstatus **confirmed** |

## Ciri-ciri

- Kalendar bulanan untuk Dewan Rakyat & Dewan Negara, dengan baki kuota setiap hari
- Pemilihan slot masa (slot yang telah ditempah dikelabukan)
- Borang tempahan dengan pengesahan input
- Panel admin (`/admin`): sahkan / batalkan tempahan, tapis, dan **eksport ke Excel (.xlsx)**
- Pembatalan membebaskan semula slot
- Perlindungan double-booking (unique index SQLite + transaksi)

## Mula pantas

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

export ADMIN_TOKEN="token-rahsia-anda"   # Windows: set ADMIN_TOKEN=...
python app.py
```

Buka http://localhost:5000 (tempahan) dan http://localhost:5000/admin (admin).

## Konfigurasi (pembolehubah persekitaran)

| Nama | Lalai | Keterangan |
|---|---|---|
| `ADMIN_TOKEN` | `tukar-token-ini` | Token panel admin. **Wajib ditukar** sebelum deploy |
| `DB_PATH` | `bookings.db` | Lokasi fail SQLite |
| `MAX_VISITS_PER_DAY` | `4` | Kuota lawatan sehari bagi setiap dewan |
| `MAX_GROUP_SIZE` | `50` | Had peserta setiap tempahan |
| `PORT` | `5000` | Port pelayan |

## API ringkas

| Kaedah | Laluan | Keterangan |
|---|---|---|
| GET | `/api/availability?month=YYYY-MM&house=...` | Ketersediaan kalendar |
| GET | `/api/slots?date=YYYY-MM-DD&house=...` | Slot untuk satu hari |
| POST | `/api/bookings` | Buat tempahan |
| GET | `/api/admin/bookings` | Senarai (header `X-Admin-Token`) |
| POST | `/api/admin/bookings/<id>/status` | Sahkan / batal |
| GET | `/api/admin/export.xlsx` | Eksport Excel (disahkan sahaja) |

## Ujian

```bash
pytest -q
```

## Deploy

Untuk produksi, guna pelayan WSGI, contohnya:

```bash
pip install gunicorn
gunicorn -w 2 app:app
```

> Nota: hari cuti umum / sidang Parlimen belum disekat secara automatik. Tambah tarikh ditutup dalam `check_date()` di `app.py` jika perlu.

## Lesen

MIT
