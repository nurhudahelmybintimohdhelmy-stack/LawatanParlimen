"""Sistem Tempahan Lawatan Parlimen Malaysia.

Peraturan:
- Lawatan hanya boleh ditempah Isnin hingga Khamis (Sabtu, Ahad & Jumaat ditutup).
- 8 slot sehari, 09:00 hingga 17:00 (setiap slot 1 jam).
- Maksimum 4 lawatan sehari bagi setiap dewan (boleh ditukar dalam konfigurasi).
- Kalendar berasingan untuk Dewan Rakyat dan Dewan Negara.
- Tempahan yang telah disahkan boleh dieksport ke Excel (admin sahaja).
"""
import hmac
import os
import re
import sqlite3
from datetime import date, datetime, timedelta
from io import BytesIO
import calendar

from flask import Flask, g, jsonify, render_template, request, send_file
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# ----------------------------------------------------------------- Konfigurasi
DB_PATH = os.environ.get("DB_PATH", "bookings.db")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "tukar-token-ini")
HOUSES = ["Dewan Rakyat", "Dewan Negara"]
ALLOWED_WEEKDAYS = {0, 1, 2, 3}  # 0=Isnin ... 3=Khamis
FIRST_HOUR = 9
SLOT_COUNT = 8  # 09:00-17:00, 1 jam setiap slot
MAX_VISITS_PER_DAY = int(os.environ.get("MAX_VISITS_PER_DAY", 4))  # setiap dewan
MAX_GROUP_SIZE = int(os.environ.get("MAX_GROUP_SIZE", 50))
DAY_NAMES = ["Isnin", "Selasa", "Rabu", "Khamis", "Jumaat", "Sabtu", "Ahad"]
ACTIVE = ("pending", "confirmed")

SLOTS = [
    {"id": i, "label": f"{FIRST_HOUR + i:02d}:00 - {FIRST_HOUR + i + 1:02d}:00"}
    for i in range(SLOT_COUNT)
]

app = Flask(__name__)


# -------------------------------------------------------------------- Pangkalan data
def get_db():
    if "db" not in g:
        conn = sqlite3.connect(app.config.get("DB_PATH", DB_PATH), isolation_level=None)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(path=None):
    conn = sqlite3.connect(path or app.config.get("DB_PATH", DB_PATH))
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            visit_date TEXT NOT NULL,
            slot INTEGER NOT NULL,
            house TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            organisation TEXT,
            group_size INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            confirmed_at TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_active_slot
            ON bookings(visit_date, house, slot)
            WHERE status IN ('pending', 'confirmed');
        """
    )
    conn.commit()
    conn.close()


# -------------------------------------------------------------------- Pembantu
def err(msg, code=400):
    return jsonify({"error": msg}), code


def parse_date(value):
    try:
        return datetime.strptime(value or "", "%Y-%m-%d").date()
    except ValueError:
        return None


def check_date(d):
    """Pulangkan mesej ralat jika tarikh tidak boleh ditempah, kalau tidak None."""
    if d is None:
        return "Format tarikh tidak sah (guna YYYY-MM-DD)."
    if d.weekday() not in ALLOWED_WEEKDAYS:
        return "Lawatan hanya boleh ditempah pada hari Isnin hingga Khamis."
    if d <= date.today():
        return "Sila pilih tarikh akan datang (tempahan sehari sebelum atau lebih awal)."
    return None


def booked_slots(db, d, house):
    rows = db.execute(
        "SELECT slot FROM bookings WHERE visit_date=? AND house=? AND status IN ('pending','confirmed')",
        (d.isoformat(), house),
    ).fetchall()
    return {r["slot"] for r in rows}


def ref_code(booking_id):
    return f"PLK-{booking_id:05d}"


def is_admin():
    token = request.headers.get("X-Admin-Token", "")
    return bool(token) and hmac.compare_digest(token, ADMIN_TOKEN)


def valid_house(h):
    return h if h in HOUSES else None


# -------------------------------------------------------------------- Halaman
@app.route("/")
def index():
    return render_template("index.html", houses=HOUSES)


@app.route("/admin")
def admin_page():
    return render_template("admin.html")


# -------------------------------------------------------------------- API awam
@app.get("/api/config")
def api_config():
    return jsonify(
        houses=HOUSES,
        slots=SLOTS,
        max_visits_per_day=MAX_VISITS_PER_DAY,
        max_group_size=MAX_GROUP_SIZE,
        open_days=[DAY_NAMES[i] for i in sorted(ALLOWED_WEEKDAYS)],
    )


@app.get("/api/availability")
def api_availability():
    """Ketersediaan sebulan untuk satu dewan: ?month=YYYY-MM&house=Dewan Rakyat"""
    house = valid_house(request.args.get("house"))
    if not house:
        return err("Dewan tidak sah.")
    try:
        year, month = map(int, (request.args.get("month") or "").split("-"))
        first = date(year, month, 1)
    except ValueError:
        return err("Format bulan tidak sah (guna YYYY-MM).")
    last_day = calendar.monthrange(year, month)[1]
    db = get_db()
    rows = db.execute(
        """SELECT visit_date, COUNT(*) AS n FROM bookings
           WHERE house=? AND visit_date BETWEEN ? AND ? AND status IN ('pending','confirmed')
           GROUP BY visit_date""",
        (house, first.isoformat(), date(year, month, last_day).isoformat()),
    ).fetchall()
    counts = {r["visit_date"]: r["n"] for r in rows}
    days = []
    for n in range(1, last_day + 1):
        d = date(year, month, n)
        bookable = check_date(d) is None
        booked = counts.get(d.isoformat(), 0)
        days.append(
            {
                "date": d.isoformat(),
                "weekday": d.weekday(),
                "bookable": bookable,
                "booked": booked,
                "remaining": max(0, min(MAX_VISITS_PER_DAY - booked, SLOT_COUNT - booked)) if bookable else 0,
            }
        )
    return jsonify(house=house, month=f"{year:04d}-{month:02d}", days=days, max_per_day=MAX_VISITS_PER_DAY)


@app.get("/api/slots")
def api_slots():
    house = valid_house(request.args.get("house"))
    d = parse_date(request.args.get("date"))
    if not house:
        return err("Dewan tidak sah.")
    problem = check_date(d)
    if problem:
        return err(problem)
    taken = booked_slots(get_db(), d, house)
    day_full = len(taken) >= MAX_VISITS_PER_DAY
    return jsonify(
        date=d.isoformat(),
        house=house,
        day_full=day_full,
        remaining=max(0, MAX_VISITS_PER_DAY - len(taken)),
        slots=[{**s, "available": (s["id"] not in taken) and not day_full} for s in SLOTS],
    )


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?[0-9\s\-]{7,15}$")


@app.post("/api/bookings")
def api_create_booking():
    data = request.get_json(silent=True) or {}
    house = valid_house(data.get("house"))
    d = parse_date(data.get("date"))
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    org = (data.get("organisation") or "").strip()
    try:
        slot = int(data.get("slot"))
        size = int(data.get("group_size"))
    except (TypeError, ValueError):
        return err("Slot dan bilangan peserta mesti nombor.")

    if not house:
        return err("Dewan tidak sah.")
    problem = check_date(d)
    if problem:
        return err(problem)
    if not 0 <= slot < SLOT_COUNT:
        return err("Slot tidak sah.")
    if not name or len(name) > 100:
        return err("Nama diperlukan (maksimum 100 aksara).")
    if not EMAIL_RE.match(email):
        return err("Alamat emel tidak sah.")
    if not PHONE_RE.match(phone):
        return err("Nombor telefon tidak sah.")
    if not 1 <= size <= MAX_GROUP_SIZE:
        return err(f"Bilangan peserta mesti antara 1 dan {MAX_GROUP_SIZE}.")

    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    try:
        taken = booked_slots(db, d, house)
        if len(taken) >= MAX_VISITS_PER_DAY:
            db.execute("ROLLBACK")
            return err("Kuota lawatan hari ini telah penuh.", 409)
        if slot in taken:
            db.execute("ROLLBACK")
            return err("Slot ini telah ditempah. Sila pilih slot lain.", 409)
        cur = db.execute(
            """INSERT INTO bookings(visit_date, slot, house, name, email, phone,
                                    organisation, group_size, status, created_at)
               VALUES (?,?,?,?,?,?,?,?, 'pending', ?)""",
            (d.isoformat(), slot, house, name, email, phone, org, size, datetime.now().isoformat(timespec="seconds")),
        )
        db.execute("COMMIT")
    except sqlite3.IntegrityError:
        db.execute("ROLLBACK")
        return err("Slot ini telah ditempah. Sila pilih slot lain.", 409)
    bid = cur.lastrowid
    return jsonify(id=bid, reference=ref_code(bid), status="pending",
                   message="Tempahan diterima. Status: menunggu pengesahan."), 201


# -------------------------------------------------------------------- API admin
def row_to_dict(r):
    d = date.fromisoformat(r["visit_date"])
    return {
        "id": r["id"],
        "reference": ref_code(r["id"]),
        "date": r["visit_date"],
        "day": DAY_NAMES[d.weekday()],
        "slot": SLOTS[r["slot"]]["label"],
        "house": r["house"],
        "name": r["name"],
        "email": r["email"],
        "phone": r["phone"],
        "organisation": r["organisation"] or "",
        "group_size": r["group_size"],
        "status": r["status"],
        "created_at": r["created_at"],
        "confirmed_at": r["confirmed_at"] or "",
    }


@app.get("/api/admin/bookings")
def admin_list():
    if not is_admin():
        return err("Tidak dibenarkan.", 401)
    status = request.args.get("status")
    sql, params = "SELECT * FROM bookings", []
    if status in ("pending", "confirmed", "cancelled"):
        sql += " WHERE status=?"
        params.append(status)
    sql += " ORDER BY visit_date, slot"
    rows = get_db().execute(sql, params).fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.post("/api/admin/bookings/<int:bid>/status")
def admin_set_status(bid):
    if not is_admin():
        return err("Tidak dibenarkan.", 401)
    status = (request.get_json(silent=True) or {}).get("status")
    if status not in ("confirmed", "cancelled"):
        return err("Status mesti 'confirmed' atau 'cancelled'.")
    db = get_db()
    row = db.execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
    if not row:
        return err("Tempahan tidak dijumpai.", 404)
    if row["status"] == "cancelled":
        return err("Tempahan yang dibatalkan tidak boleh diubah.", 409)
    confirmed_at = datetime.now().isoformat(timespec="seconds") if status == "confirmed" else None
    db.execute("UPDATE bookings SET status=?, confirmed_at=? WHERE id=?", (status, confirmed_at, bid))
    return jsonify(id=bid, status=status)


@app.get("/api/admin/export.xlsx")
def admin_export():
    """Eksport tempahan yang telah DISAHKAN sahaja. Pilihan: ?from=&to=&house="""
    if not is_admin():
        return err("Tidak dibenarkan.", 401)
    sql = "SELECT * FROM bookings WHERE status='confirmed'"
    params = []
    if parse_date(request.args.get("from")):
        sql += " AND visit_date >= ?"
        params.append(request.args["from"])
    if parse_date(request.args.get("to")):
        sql += " AND visit_date <= ?"
        params.append(request.args["to"])
    if valid_house(request.args.get("house")):
        sql += " AND house = ?"
        params.append(request.args["house"])
    sql += " ORDER BY visit_date, slot, house"
    rows = [row_to_dict(r) for r in get_db().execute(sql, params).fetchall()]

    wb = Workbook()
    ws = wb.active
    ws.title = "Tempahan Disahkan"
    headers = ["Rujukan", "Tarikh", "Hari", "Masa", "Dewan", "Nama", "Emel", "Telefon",
               "Organisasi", "Bil. Peserta", "Dibuat Pada", "Disahkan Pada"]
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3864")
        c.alignment = Alignment(horizontal="center", vertical="center")
    for r in rows:
        ws.append([r["reference"], date.fromisoformat(r["date"]), r["day"], r["slot"], r["house"],
                   r["name"], r["email"], r["phone"], r["organisation"], r["group_size"],
                   r["created_at"].replace("T", " "), r["confirmed_at"].replace("T", " ")])
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=2):
        row[0].number_format = "DD/MM/YYYY"
    for i, h in enumerate(headers, 1):
        width = max([len(str(h))] + [len(str(ws.cell(row=n, column=i).value or "")) for n in range(2, ws.max_row + 1)])
        ws.column_dimensions[get_column_letter(i)].width = min(width + 3, 40)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"tempahan-disahkan-{date.today().isoformat()}.xlsx"
    return send_file(buf, as_attachment=True, download_name=fname,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
